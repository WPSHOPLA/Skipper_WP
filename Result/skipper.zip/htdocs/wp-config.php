<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'skipper');

/** MySQL database username */
define('DB_USER', 'skipper');

/** MySQL database password */
define('DB_PASSWORD', '21f2d8da88');

/** MySQL hostname */
define('DB_HOST', 'localhost:3306');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'd29908c60e8d0ec87b84ee9508bea0815796d8e23d6cfb960c151cf21ebf427b');
define('SECURE_AUTH_KEY',  '9b2e474eac18ad076893b23c9ec780aeec65761a9241c32c5e79e4fa675dfcc2');
define('LOGGED_IN_KEY',    'bc818162df97f2bd88b4b53162c2d0787afdec314d7ff1507e44845b93a4f6c9');
define('NONCE_KEY',        '78a1a3d7bc87e4e8c0abb82dacd409859320aa190c86a78771c31a1a479f41d6');
define('AUTH_SALT',        '738d269ee8bd3ca255b6732cc98dc4264fe7db31de31bed6510a8f0fba2bf226');
define('SECURE_AUTH_SALT', '8910dd9544b6bb6a0d5125369d2133b97d4320246814071eac11d0fe7c074ea2');
define('LOGGED_IN_SALT',   'd6cfc8aab7b57682e90890327f7e7cc2fb9253b0643f105f2523d9a7b39331d3');
define('NONCE_SALT',       '9b4202511b5139a9715a9933bcb8c6509516e735cc48e69aae3dbbc1605a1a25');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */
/**
 * The WP_SITEURL and WP_HOME options are configured to access from any hostname or IP address.
 * If you want to access only from an specific domain, you can modify them. For example:
 *  define('WP_HOME','http://example.com');
 *  define('WP_SITEURL','http://example.com');
 *
*/

define('WP_SITEURL', 'http://' . $_SERVER['HTTP_HOST'] . '/skipper');
define('WP_HOME', 'http://' . $_SERVER['HTTP_HOST'] . '/skipper');



/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define('WP_TEMP_DIR', 'C:/xampp/apps/skipper/tmp');

define('JS_PATH', 'http://' . $_SERVER['HTTP_HOST'] . '/skipper/wp-content/themes/twentysixteen/js/');
define('CSS_PATH', 'http://' . $_SERVER['HTTP_HOST'] . '/skipper/wp-content/themes/twentysixteen/css/');
define('IMG_PATH', 'http://' . $_SERVER['HTTP_HOST'] . '/skipper/wp-content/uploads/2016/05/');

